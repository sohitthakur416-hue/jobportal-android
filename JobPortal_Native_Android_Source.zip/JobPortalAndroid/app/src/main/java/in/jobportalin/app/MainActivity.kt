package in.jobportalin.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private const val SUPABASE_URL = "https://zaechwffuduehadmxzxw.supabase.co"
private const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_pvzySCsyXT4ayURKZjsW2g_5W0FDBsh"

private val Navy = Color(0xFF102B52)
private val Blue = Color(0xFF2563EB)
private val Page = Color(0xFFF5F7FB)

data class Job(
    val id: String,
    val title: String,
    val organization: String,
    val category: String,
    val qualification: String,
    val location: String,
    val totalPosts: String,
    val startDate: String,
    val lastDate: String,
    val description: String,
    val officialUrl: String,
    val pdfUrl: String
)

private fun JSONArray.toJobs(): List<Job> = buildList {
    for (i in 0 until length()) {
        val o = getJSONObject(i)
        add(
            Job(
                id = o.optString("id"),
                title = o.optString("title", "Untitled vacancy"),
                organization = o.optString("organization", ""),
                category = o.optString("category", "latest"),
                qualification = o.optString("qualification", "As per notification"),
                location = o.optString("location", "India"),
                totalPosts = if (o.isNull("total_posts")) "Not specified" else o.optString("total_posts"),
                startDate = o.optString("application_start", ""),
                lastDate = o.optString("last_date", ""),
                description = o.optString("description", "Please read the official notification carefully."),
                officialUrl = o.optString("official_url", ""),
                pdfUrl = o.optString("notification_pdf_url", "")
            )
        )
    }
}

private suspend fun fetchPublishedJobs(): List<Job> = withContext(Dispatchers.IO) {
    val columns = "id,title,organization,category,qualification,location,total_posts,application_start,last_date,description,official_url,notification_pdf_url,status,created_at"
    val endpoint = "$SUPABASE_URL/rest/v1/jobs?select=$columns&status=eq.published&order=created_at.desc"
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 15000
        setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY)
        setRequestProperty("Authorization", "Bearer $SUPABASE_PUBLISHABLE_KEY")
        setRequestProperty("Accept", "application/json")
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("Supabase error ($code): $body")
        JSONArray(body).toJobs()
    } finally {
        connection.disconnect()
    }
}

private fun categoryName(category: String): String = when (category) {
    "latest" -> "Latest Jobs"
    "central" -> "Central Jobs"
    "upcoming" -> "Upcoming"
    "admission" -> "Admission"
    "offline" -> "Offline Form"
    else -> category.replaceFirstChar { it.uppercase() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JobsPortalApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JobsPortalApp() {
    var jobs by remember { mutableStateOf<List<Job>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("all") }
    var selectedJob by remember { mutableStateOf<Job?>(null) }

    suspend fun reload() {
        loading = true
        error = null
        try {
            jobs = fetchPublishedJobs()
        } catch (e: Exception) {
            error = e.message ?: "Could not load jobs."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }

    val filtered = jobs.filter { job ->
        val matchesCategory = category == "all" || job.category == category
        val haystack = "${job.title} ${job.organization} ${job.qualification} ${job.location} ${categoryName(job.category)}"
        matchesCategory && haystack.contains(query, ignoreCase = true)
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Blue,
            background = Page,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Page,
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(
                                        androidx.compose.ui.graphics.Brush.linearGradient(listOf(Blue, Color(0xFF12A5A0))),
                                        RoundedCornerShape(10.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("JP", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                            }
                            Spacer(Modifier.width(9.dp))
                            Text("JobsPortal", color = Navy, fontWeight = FontWeight.ExtraBold)
                        }
                    },
                    actions = {
                        TextButton(onClick = { /* reload handled by refresh button below */ }) {
                            Text(" ", color = Blue)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(14.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Navy, Color(0xFF1B477D))),
                            RoundedCornerShape(22.dp)
                        )
                        .padding(20.dp)
                ) {
                    Text("YOUR CAREER UPDATE DESK", color = Color(0xFFBFD7F7), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Find your next\nopportunity.", color = Color.White, fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Government jobs, admissions aur application forms — sab ek jagah.", color = Color(0xFFE0ECFC), fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⌕", color = Blue, fontSize = 22.sp)
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f)) {
                            if (query.isEmpty()) Text("Search jobs, department, qualification…", color = Color.Gray, fontSize = 13.sp)
                            BasicTextField(
                                value = query,
                                onValueChange = { query = it },
                                singleLine = true,
                                textStyle = androidx.compose.ui.text.TextStyle(color = Navy, fontSize = 13.sp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Explore categories", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy)
                    TextButton(onClick = { category = "all" }) { Text("View all") }
                }
                val categories = listOf("all" to "All", "latest" to "Latest", "central" to "Central", "upcoming" to "Upcoming", "admission" to "Admission", "offline" to "Offline")
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    categories.take(3).forEach { (key, label) ->
                        FilterChip(selected = category == key, onClick = { category = key }, label = { Text(label, fontSize = 11.sp) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth()) {
                    categories.drop(3).forEach { (key, label) ->
                        FilterChip(selected = category == key, onClick = { category = key }, label = { Text(label, fontSize = 11.sp) })
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(if (category == "all") "Latest updates" else categoryName(category), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.weight(1f))
                    TextButton(onClick = { kotlinx.coroutines.MainScope().launch { reload() } }) { Text("Refresh") }
                }

                when {
                    loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) }
                    error != null -> Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("Jobs load nahi ho paayi", color = Navy, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(error ?: "", color = Color(0xFFB91C1C), fontSize = 12.sp)
                        TextButton(onClick = { kotlinx.coroutines.MainScope().launch { reload() } }) { Text("Try again") }
                    }
                    filtered.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("Abhi koi published listing nahi mili.", color = Color.Gray)
                    }
                    else -> LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 22.dp)
                    ) {
                        items(filtered, key = { it.id }) { job ->
                            JobCard(job = job, onClick = { selectedJob = job })
                        }
                    }
                }
            }
        }

        selectedJob?.let { job ->
            ModalBottomSheet(onDismissRequest = { selectedJob = null }) {
                JobDetails(job = job)
            }
        }
    }
}

@Composable
private fun JobCard(job: Job, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(job.title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(3.dp))
                    Text(job.organization, color = Color(0xFF64748B), fontSize = 12.sp)
                }
                Text(
                    categoryName(job.category),
                    color = Blue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(Color(0xFFEAF2FF), RoundedCornerShape(50))
                        .padding(horizontal = 9.dp, vertical = 6.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            Text("🎓  ${job.qualification}", color = Color(0xFF536277), fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text("📍  ${job.location}     •     Posts: ${job.totalPosts}", color = Color(0xFF536277), fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFFE8EDF4))
            Spacer(Modifier.height(8.dp))
            Text("Last date: ${job.lastDate.ifBlank { "Not announced" }}     › View details", color = Color(0xFF9A5A08), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun JobDetails(job: Job) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp)) {
        Text(job.title, fontSize = 21.sp, color = Navy, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text(job.organization, color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        DetailLine("Category", categoryName(job.category))
        DetailLine("Qualification", job.qualification)
        DetailLine("Location", job.location)
        DetailLine("Total posts", job.totalPosts)
        DetailLine("Application starts", job.startDate.ifBlank { "Not announced" })
        DetailLine("Last date", job.lastDate.ifBlank { "Not announced" })
        Spacer(Modifier.height(10.dp))
        Text("Details", fontWeight = FontWeight.Bold, color = Navy, fontSize = 16.sp)
        Spacer(Modifier.height(5.dp))
        Text(job.description, color = Color(0xFF475569), fontSize = 13.sp, lineHeight = 20.sp)
        Spacer(Modifier.height(18.dp))
        if (job.officialUrl.startsWith("https://")) {
            Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(job.officialUrl))) }, modifier = Modifier.fillMaxWidth()) {
                Text("Apply / Official Website")
            }
        }
        if (job.pdfUrl.startsWith("https://")) {
            OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(job.pdfUrl))) }, modifier = Modifier.fillMaxWidth()) {
                Text("Open Notification PDF")
            }
        }
        Text("Important: Apply karne se pehle official notification zaroor verify karein.", color = Color(0xFF9A5A08), fontSize = 11.sp)
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = Navy, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
    }
}
