# JobsPortal Native Android App

Yeh Kotlin + Jetpack Compose Android Studio starter project hai. App tumhare existing Supabase `public.jobs` table se live data read karti hai aur sirf `status = published` wali jobs dikhati hai.

## App details
- App name: JobsPortal
- Package ID: `in.jobportalin.app` (Play Store listing banane se pehle final rakhna; publish ke baad badalna mushkil hota hai)
- Native UI: Kotlin + Jetpack Compose (WebView nahi)
- Backend: existing Supabase project
- Minimum Android: Android 7.0 (API 24)
- Compile SDK: 37
- Target SDK: 36 (31 October 2026 ke Google Play requirement ke mutabik)

## Existing website/backend connection
- Website: https://jobsportalin.netlify.app
- Supabase project: existing JobsPortal project
- Table: `public.jobs`
- Public query: `status = published`, newest first
- Read columns: `id,title,organization,category,qualification,location,total_posts,application_start,last_date,description,official_url,notification_pdf_url,status,created_at`
- App mein admin login, create/update/delete ya database write permission nahi hai.

**Security:** Android app mein sirf Supabase publishable key use hoti hai. Secret/service_role key kabhi Android app, website ya public repository mein mat daalna. Supabase RLS policy se anonymous users ko sirf published rows read karne do. Agar public read policy configured nahi hai to app empty/error state dikhayegi; service-role key se workaround mat karna.

## Android Studio setup
1. ZIP extract karo.
2. Computer/laptop par latest stable Android Studio install karo.
3. Android Studio mein **Open** karke extracted `JobPortalAndroid` folder select karo.
4. SDK Manager se Android SDK Platform 37 aur Android SDK Build-Tools install karo.
5. Gradle sync complete hone do; zaroorat par Android Studio ke suggested Gradle/JDK setup ko accept karo. JDK 17 ya compatible bundled JDK use karo.
6. Emulator ya USB debugging enabled Android phone connect karke Run ▶ dabao.
7. Search, category filters, job details, official apply link, notification PDF aur refresh test karo.

## Current starter features
- Native Compose home screen
- Supabase se published jobs load
- Search + category filters
- Job detail bottom sheet
- Official apply website aur notification PDF open
- Loading, empty, error aur refresh states

## Abhi baaki development / release work
- App icon, branded splash screen aur final UI polish
- Firebase Cloud Messaging push notifications (abhi included nahi)
- Privacy policy ko actual published URL par host karna
- Google Play Data safety, content rating, app access aur store listing forms
- Release signing key aur signed Android App Bundle (.aab)
- Real device testing; is source ko yahan Android SDK/Gradle se compile karke verify nahi kiya gaya hai

## Play Store
- Play Console developer account ki one-time fee US$25 hai (payment options region ke hisaab se vary kar sakte hain).
- Naye personal developer accounts ke liye closed test mein kam-se-kam 12 testers ko 14 din continuously opted-in rakhna hota hai, phir production access apply hota hai.
- New apps ko 31 August 2026 se Android 16 / API 36 ya usse upar target karna hota hai; project targetSdk 36 set karta hai.

Official guides:
- https://support.google.com/googleplay/android-developer/answer/6112435
- https://support.google.com/googleplay/android-developer/answer/14151465
- https://developer.android.com/google/play/requirements/target-sdk
