# JobsPortal App Privacy Policy

Effective date: [ADD DATE]

JobsPortal is an independent information platform that displays job, admission and application-form updates.

## Information we collect
The current app version does not ask users to create an account and does not intentionally collect personal profile information. The app requests publicly published listing data from its Supabase backend.

## External websites
When users open an official application website or notification PDF, they leave the app and are subject to that external website's privacy policy.

## Data storage and security
Job listings are hosted by the JobsPortal backend. The app uses an internet connection to retrieve listings. Do not include private credentials or service-role keys in the app.

## Contact
For privacy questions, contact: [ADD SUPPORT EMAIL]

This is a starter template, not legal advice. Complete the placeholders and confirm the policy matches the final app and all SDKs before publishing.
