# JobPortal App - Next Steps

## Step 1: First Android build
- Android Studio mein project open karo.
- SDK Platform 37 install karo.
- Gradle sync ke baad app ko emulator/Android phone par run karo.
- Agar red error aaye to Build Output ka screenshot ya exact error share karo.

## Step 2: Test live data
- Website admin se ek test job `Published` karo.
- App mein Refresh dabao.
- Confirm karo ki published job dikh rahi hai aur Draft/Closed nahi dikh rahi.
- Job detail, Apply URL aur PDF link test karo.

## Step 3: Production features
- App icon and splash screen
- FCM push notifications
- Privacy policy page
- Accessibility, crash and network error testing

## Step 4: Google Play
- Play Console account create and identity verification
- App listing, screenshots, privacy policy, Data safety and content rating
- Signed AAB upload
- Personal account ho to 12 testers / 14-day closed test and production access request

**Important:** Source project APK/AAB nahi hai. AAB Android Studio se release build ke roop mein generate karna hoga. Signing key ko safe backup mein rakho; ise public share mat karo.
